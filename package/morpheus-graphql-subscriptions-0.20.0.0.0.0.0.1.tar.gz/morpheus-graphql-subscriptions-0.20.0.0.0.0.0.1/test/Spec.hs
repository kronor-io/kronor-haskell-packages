{-# LANGUAGE NoImplicitPrelude #-}

module Main
  ( main,
  )
where

import Prelude
  ( IO,
    pure,
  )

main :: IO ()
main = pure ()
