# Morpheus GraphQL Code Gen

generates Morpheus APIs from GraphQL documents (see [Code Gen Docs](https://morpheusgraphql.com/code-gen)).
