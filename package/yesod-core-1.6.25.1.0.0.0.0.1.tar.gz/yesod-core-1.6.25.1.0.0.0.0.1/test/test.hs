import Test.Hspec
import qualified YesodCoreTest

main :: IO ()
main = hspec YesodCoreTest.specs
