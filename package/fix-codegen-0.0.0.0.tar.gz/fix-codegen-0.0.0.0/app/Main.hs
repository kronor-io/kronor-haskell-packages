module Main (main) where

import FIX.CodeGen

main :: IO ()
main = runFixCodeGen
