module Ast.InExprSpec (spec) where

import Helpers.Specs
import PostgresqlSyntax.Ast.InExpr
import Test.Hspec

spec :: Spec
spec = do
  itSatisfiesIsAst @InExpr
  itSatisfiesCanonicalizes @InExpr
  itSatisfiesArbitrary @InExpr
