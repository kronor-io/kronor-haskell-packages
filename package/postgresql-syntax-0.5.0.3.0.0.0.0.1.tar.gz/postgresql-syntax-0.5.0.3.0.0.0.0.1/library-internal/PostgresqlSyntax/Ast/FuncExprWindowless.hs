module PostgresqlSyntax.Ast.FuncExprWindowless where

import PostgresqlSyntax.Algebra
import PostgresqlSyntax.Ast.FuncApplication
import PostgresqlSyntax.Ast.FuncExprCommonSubexpr
import PostgresqlSyntax.Prelude
import qualified Test.QuickCheck as Qc

-- |
-- ==== References
-- @
-- func_expr_windowless:
--   | func_application
--   | func_expr_common_subexpr
-- @
data FuncExprWindowless
  = ApplicationFuncExprWindowless FuncApplication
  | CommonSubexprFuncExprWindowless FuncExprCommonSubexpr
  deriving (Show, Generic, Eq, Ord, Data)

instance IsAst FuncExprWindowless where
  toTextBuilder settings = \case
    ApplicationFuncExprWindowless a -> toTextBuilder settings a
    CommonSubexprFuncExprWindowless a -> toTextBuilder settings a
  parser settings =
    asum
      [ CommonSubexprFuncExprWindowless <$> parser settings,
        ApplicationFuncExprWindowless <$> parser settings
      ]

instance Qc.Arbitrary FuncExprWindowless where
  shrink = Qc.genericShrink
  arbitrary =
    Qc.oneof
      [ ApplicationFuncExprWindowless <$> Qc.arbitrary,
        CommonSubexprFuncExprWindowless <$> Qc.arbitrary
      ]
