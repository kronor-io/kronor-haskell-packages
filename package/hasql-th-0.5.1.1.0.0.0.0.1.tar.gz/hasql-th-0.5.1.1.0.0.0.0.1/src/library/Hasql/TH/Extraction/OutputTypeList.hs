{-# OPTIONS_GHC -Wno-unused-binds -Wno-unused-imports -Wno-name-shadowing -Wno-incomplete-patterns -Wno-unused-matches -Wno-missing-methods -Wno-unused-record-wildcards -Wno-redundant-constraints -Wno-deprecations -Wno-missing-signatures #-}

-- |
-- AST traversal extracting output types.
module Hasql.TH.Extraction.OutputTypeList where

import Hasql.TH.Prelude
import PostgresqlSyntax

foldable :: (Foldable f) => (a -> Either Text [Typename]) -> f a -> Either Text [Typename]
foldable fn = fmap join . traverse fn . toList

preparableStmt = \case
  SelectPreparableStmt a -> selectStmt a
  InsertPreparableStmt a -> insertStmt a
  UpdatePreparableStmt a -> updateStmt a
  DeletePreparableStmt a -> deleteStmt a
  CallPreparableStmt a -> callStmt a

-- * Call

callStmt (CallStmt a) =
  Right []

-- * Insert

insertStmt (InsertStmt a b c d e) = foldable returningClause e

returningClause (ReturningClause a) = targetList a

-- * Update

updateStmt (UpdateStmt _ _ _ _ _ a) = foldable returningClause a

-- * Delete

deleteStmt (DeleteStmt _ _ _ _ a) = foldable returningClause a

-- * Select

selectStmt = \case
  NoParensSelectStmt a -> selectNoParens a
  WithParensSelectStmt a -> selectWithParens a

selectNoParens (SelectNoParens _ a _ _ _) = selectClause a

selectWithParens = \case
  NoParensSelectWithParens a -> selectNoParens a
  WithParensSelectWithParens a -> selectWithParens a

selectClause = \case
  SimpleSelectSelectClause a -> simpleSelect a
  WithParensSelectClause a -> selectWithParens a

simpleSelect = \case
  NormalSimpleSelect a _ _ _ _ _ _ -> foldable targeting a
  ValuesSimpleSelect a -> valuesClause a
  TableSimpleSelect _ -> Left "TABLE cannot be used as a final statement, since it's impossible to specify the output types"
  BinSimpleSelect _ a _ b -> do
    c <- selectClause a
    d <- selectClause b
    if c == d
      then return c
      else Left "Merged queries produce results of incompatible types"

targeting :: Targeting -> Either Text [Typename]
targeting = \case
  NormalTargeting a -> hsTargetList a
  AllTargeting a -> foldable targetList a
  DistinctTargeting _ b -> targetList b

-- |
-- Collect the 'SqlTargetEl' leaves of a Haskell target list, depth-first and
-- left-to-right. That is the order the columns come back in, and it must stay
-- the order "Hasql.TH.Extraction.OutputHsTarget" ticks its @fn@ counter in.
hsTargetList :: HsTargetList -> Either Text [Typename]
hsTargetList (HsTargetList a) = foldable hsTargetEl a

hsTargetEl :: HsTargetEl -> Either Text [Typename]
hsTargetEl = \case
  HsRecTargetEl _ a -> foldable hsFieldTargetEl a
  HsFuncTargetEl _ a -> foldable hsTargetEl a
  SqlTargetEl a -> targetEl a

hsFieldTargetEl :: HsFieldTargetEl -> Either Text [Typename]
hsFieldTargetEl (HsFieldEl _ a) = hsTargetEl a

targetList :: TargetList -> Either Text [Typename]
targetList (TargetList a) = foldable targetEl a

targetEl = \case
  AliasedExprTargetEl a _ -> aExpr a
  ImplicitlyAliasedExprTargetEl a _ -> aExpr a
  ExprTargetEl a -> aExpr a
  AsteriskTargetEl ->
    Left
      "Target of all fields is not allowed, \
      \because it leaves the output types unspecified. \
      \You have to be specific."

valuesClause (ValuesClause a) = foldable (\(ExprList b) -> foldable aExpr b) a

aExpr = \case
  CExprAExpr a -> cExpr a
  TypecastAExpr _ a -> Right [a]
  a -> Left "Result expression is missing a typecast"

cExpr = \case
  InParensCExpr a Nothing -> aExpr a
  a -> Left "Result expression is missing a typecast"
