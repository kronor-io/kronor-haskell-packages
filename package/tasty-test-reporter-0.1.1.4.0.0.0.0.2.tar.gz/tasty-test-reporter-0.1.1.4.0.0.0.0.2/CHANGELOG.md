# 0.1.1.4

- Fix error in version 0.1.1.3 that prevented that version from compiling.

# 0.1.1.3

- Relax version bounds to include `tasty` 1.4.

# 0.1.1.2

- Relax version bounds of `tasty` and `ansi-terminal` dependencies.

# 0.1.0.0

- Initial implementation.
