{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE ImportQualifiedPost #-}
{-# LANGUAGE NamedFieldPuns #-}
{-# LANGUAGE NoImplicitPrelude #-}

module PgQuery.Internal.Parse where

import Control.Applicative (pure)
import Control.Monad.Fail (fail)
import Data.Bool (Bool (False, True))
import Data.ByteString (ByteString, packCStringLen, useAsCStringLen)
import Data.Either (Either (Left, Right))
import Data.Eq (Eq, (==))
import Data.Function (($))
import Data.String (String)
import Data.Text (Text)
import Data.Text qualified as Text
import Foreign
  ( Ptr,
    Storable
      ( alignment,
        peek,
        peekByteOff,
        poke,
        sizeOf
      ),
    nullPtr,
  )
import Foreign.C
  ( CInt,
    CSize,
    CString,
    peekCString,
    withCString,
  )
import Foreign.C.Types (CSize (..))
import GHC.Err (undefined)
import GHC.IO (IO)
import GHC.Num ((*), (+))
import GHC.Real (fromIntegral)
import GHC.Show (Show)

-- | Data type corresponding to the following struct in 'pg_query.h':
--
--   @
--     typedef struct {
--       size_t len;
--       char* data;
--     } PgQueryProtobuf;
--   @
data PgQueryProtobuf = PgQueryProtobuf
  { len :: CSize
  , protobufData :: CString
  }
  deriving (Show, Eq)

instance Storable PgQueryProtobuf where
  sizeOf _ =
    sizeOf (undefined :: CSize)
      + sizeOf (undefined :: CString)

  alignment _ = alignment (undefined :: PgQueryProtobuf)

  peek ptr = do
    len <- peekByteOff ptr 0
    protobufData <- peekByteOff ptr (1 * sizeOf (undefined :: CSize))
    pure
      PgQueryProtobuf
        { len
        , protobufData
        }

  poke _ _ = fail "PgQueryProtobuf poke: not supported"

-- | Data type corresponding to the following struct in 'pg_query.h':
--
--   @
--     typedef struct {
--     	char* message; // exception message
--     	char* funcname; // source function of exception (e.g. SearchSysCache)
--     	char* filename; // source of exception (e.g. parse.l)
--     	int lineno; // source of exception (e.g. 104)
--     	int cursorpos; // char in query at which exception occurred
--     	char* context; // additional context (optional, can be NULL)
--     } PgQueryError;
--   @
data PgQueryError = PgQueryError
  { message :: CString
  , funcname :: CString
  , filename :: CString
  , lineno :: CInt
  , cursorpos :: CInt
  , context :: CString
  }
  deriving (Show, Eq)

instance Storable PgQueryError where
  sizeOf _ =
    sizeOf (undefined :: CString)
      + sizeOf (undefined :: CString)
      + sizeOf (undefined :: CString)
      + sizeOf (undefined :: CInt)
      + sizeOf (undefined :: CInt)
      + sizeOf (undefined :: CString)

  alignment _ = alignment (undefined :: PgQueryError)

  peek ptr = do
    message <- peekByteOff ptr 0
    funcname <- peekByteOff ptr (1 * sizeOf (undefined :: CString))
    filename <- peekByteOff ptr (2 * sizeOf (undefined :: CString))
    lineno <- peekByteOff ptr (3 * sizeOf (undefined :: CString))
    cursorpos <- peekByteOff ptr ((3 * sizeOf (undefined :: CString)) + sizeOf (undefined :: CInt))
    context <- peekByteOff ptr ((4 * sizeOf (undefined :: CString)) + (2 * sizeOf (undefined :: CInt)))
    pure
      PgQueryError
        { message
        , funcname
        , filename
        , lineno
        , cursorpos
        , context
        }

  poke _ _ = fail "PgQueryError poke: not supported"

-- | Data type corresponding to the following struct in 'pg_query.h':
--
--   @
--     typedef struct {
--       PgQueryProtobuf parse_tree;
--       char* stderr_buffer;
--       PgQueryError* error;
--     } PgQueryProtobufParseResult;
--   @
data PgQueryProtobufParseResult = PgQueryProtobufParseResult
  { parse_tree :: PgQueryProtobuf
  , stderr_buffer :: CString
  , pg_query_error :: Ptr PgQueryError
  }
  deriving (Show)

instance Storable PgQueryProtobufParseResult where
  sizeOf _ =
    sizeOf (undefined :: PgQueryProtobuf)
      + sizeOf (undefined :: CString)
      + sizeOf (undefined :: Ptr PgQueryError)

  alignment _ = alignment (undefined :: PgQueryProtobufParseResult)

  peek ptr = do
    parse_tree <- peekByteOff ptr 0
    stderr_buffer <- peekByteOff ptr (sizeOf (undefined :: PgQueryProtobuf))
    pg_query_error <- peekByteOff ptr (sizeOf (undefined :: PgQueryProtobuf) + sizeOf (undefined :: CString))
    pure
      PgQueryProtobufParseResult
        { parse_tree
        , stderr_buffer
        , pg_query_error
        }

  poke _ _ = fail "PgQueryProtobufParseResult poke: not supported"

foreign import ccall "get_sql"
  get_sql ::
    CString ->
    IO (Ptr PgQueryProtobufParseResult)

foreign import ccall "free_sql"
  free_sql ::
    Ptr PgQueryProtobufParseResult ->
    IO ()

getProtobufParseResult :: String -> IO (Either String ByteString)
getProtobufParseResult sql = do
  resultPtr <- withCString sql get_sql
  result <- peek resultPtr

  let errPtr = pg_query_error result
  case errPtr == nullPtr of
    True -> do
      let tree = parse_tree result
      protobufResult <- packCStringLen (protobufData tree, fromIntegral $ len tree)

      free_sql resultPtr

      pure $ Right protobufResult
    False -> do
      errorResult <- peek errPtr
      errorMessage <- peekCString (message errorResult)

      free_sql resultPtr

      pure $ Left errorMessage

-- | Data type corresponding to the following struct in 'pg_query.h':
--
--   @
--     typedef struct {
--       char* plpgsql_funcs;
--       PgQueryError* error;
--     } PgQueryPlpgsqlParseResult;
--   @
data PgQueryPlpgsqlParseResult = PgQueryPlpgsqlParseResult
  { plpgsql_funcs :: CString
  , plpgsql_error :: Ptr PgQueryError
  }
  deriving (Show)

instance Storable PgQueryPlpgsqlParseResult where
  sizeOf _ = sizeOf (undefined :: CString) + sizeOf (undefined :: Ptr PgQueryError)
  alignment _ = alignment (undefined :: PgQueryPlpgsqlParseResult)
  peek ptr = do
    plpgsql_funcs <- peekByteOff ptr 0
    plpgsql_error <- peekByteOff ptr (sizeOf (undefined :: CString))
    pure PgQueryPlpgsqlParseResult {plpgsql_funcs, plpgsql_error}
  poke _ _ = fail "PgQueryPlpgsqlParseResult poke: not supported"

foreign import ccall "get_plpgsql"
  get_plpgsql ::
    CString ->
    IO (Ptr PgQueryPlpgsqlParseResult)

foreign import ccall "free_plpgsql"
  free_plpgsql ::
    Ptr PgQueryPlpgsqlParseResult ->
    IO ()

-- | Parse a PL/pgSQL function body using libpg_query's
--   @pg_query_parse_plpgsql@. The input is the full statement
--   (@CREATE FUNCTION ... AS $$ ... $$ LANGUAGE plpgsql@), not just
--   the body payload; libpg_query's plpgsql parser expects the
--   surrounding @CREATE FUNCTION@ context.
--
--   Returns the JSON the C library produces; libpg_query does not
--   expose the plpgsql AST via protobuf, so callers parse the JSON
--   themselves.
getPlpgsqlParseResult :: String -> IO (Either String Text)
getPlpgsqlParseResult sql = do
  resultPtr <- withCString sql get_plpgsql
  result <- peek resultPtr

  let errPtr = plpgsql_error result
  case errPtr == nullPtr of
    True -> do
      jsonStr <- peekCString (plpgsql_funcs result)
      free_plpgsql resultPtr
      pure $ Right (Text.pack jsonStr)
    False -> do
      errorResult <- peek errPtr
      errorMessage <- peekCString (message errorResult)
      free_plpgsql resultPtr
      pure $ Left errorMessage

-- | Data type corresponding to the following struct in 'pg_query.h':
--
--   @
--     typedef struct {
--       char* query;
--       PgQueryError* error;
--     } PgQueryDeparseResult;
--   @
data PgQueryDeparseResult = PgQueryDeparseResult
  { deparse_query :: CString
  , deparse_error :: Ptr PgQueryError
  }
  deriving (Show)

instance Storable PgQueryDeparseResult where
  sizeOf _ = sizeOf (undefined :: CString) + sizeOf (undefined :: Ptr PgQueryError)
  alignment _ = alignment (undefined :: PgQueryDeparseResult)
  peek ptr = do
    deparse_query <- peekByteOff ptr 0
    deparse_error <- peekByteOff ptr (sizeOf (undefined :: CString))
    pure PgQueryDeparseResult {deparse_query, deparse_error}
  poke _ _ = fail "PgQueryDeparseResult poke: not supported"

foreign import ccall "get_deparse"
  get_deparse ::
    CString ->
    CSize ->
    IO (Ptr PgQueryDeparseResult)

foreign import ccall "free_deparse"
  free_deparse ::
    Ptr PgQueryDeparseResult ->
    IO ()

-- | Re-serialize a libpg_query protobuf parse tree to a SQL string
--   via @pg_query_deparse_protobuf@. The input is the raw protobuf
--   bytes (as produced by 'getProtobufParseResult', or a hand-crafted
--   tree built with proto-lens). Returns the deparsed SQL.
getDeparseResult :: ByteString -> IO (Either String Text)
getDeparseResult protoBytes =
  useAsCStringLen protoBytes $ \(ptr, len) -> do
    resultPtr <- get_deparse ptr (fromIntegral len)
    result <- peek resultPtr

    let errPtr = deparse_error result
    case errPtr == nullPtr of
      True -> do
        sqlStr <- peekCString (deparse_query result)
        free_deparse resultPtr
        pure $ Right (Text.pack sqlStr)
      False -> do
        errorResult <- peek errPtr
        errorMessage <- peekCString (message errorResult)
        free_deparse resultPtr
        pure $ Left errorMessage
