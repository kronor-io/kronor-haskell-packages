main :: IO ()
main =
    print
        "Version bounds do not conflict when both streamly and ghc are dependencies."
