-- |
-- Module      : Streamly.Data.Fold.Tee
-- Copyright   : (c) 2021 Composewell Technologies
-- License     : BSD-3-Clause
-- Maintainer  : streamly@composewell.com
-- Stability   : released
-- Portability : GHC
--
module Streamly.Data.Fold.Tee
{-# DEPRECATED "Please use Streamly.Data.Fold module from the streamly-core package." #-}
    ( Tee(..)
    , toFold
    )
where

import Streamly.Internal.Data.Fold
