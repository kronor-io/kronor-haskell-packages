# serversession-frontend-yesod

This package provide Yesod bindings for the `serversession`
package.  Please
[read the main README file](https://github.com/yesodweb/serversession/blob/master/README.md)
for general information about the serversession packages.
