-- | Password tests.
module Password (pwdTests) where

import qualified Data.ByteString as B
import           Data.String (fromString)

import Crypto.Store.PKCS5

import Test.Tasty
import Test.Tasty.QuickCheck

arbitraryUnicode :: Gen String
arbitraryUnicode = listOf $ oneof
    [ choose ('\x0', '\x7f')
    , choose ('\x80', '\x7ff')
    , choose ('\x800', '\xffff')
    , choose ('\x10000', '\x10ffff')
    ]

pwdTests :: TestTree
pwdTests = testGroup "PKCS5.properties"
    [ testProperty "converting unicode passwords" $ do
        chars <- arbitraryUnicode
        return $ Just chars === passwordToString (fromString chars)
    , testProperty "detecting invalid sequences" $ do
        prefix <- fromProtectionPassword . fromString <$> arbitraryUnicode
        suffix <- fromProtectionPassword . fromString <$> arbitraryUnicode
        bad <- elements [ B.pack [ 0x82 ]
                        , B.pack [ 0xc2, 0x0c ]
                        , B.pack [ 0xe2, 0x0c, 0x82 ]
                        , B.pack [ 0xe2, 0x82, 0x0c ]
                        , B.pack [ 0xf2, 0x0c, 0x82, 0x82 ]
                        , B.pack [ 0xf2, 0x82, 0x0c, 0x82 ]
                        , B.pack [ 0xf2, 0x82, 0x82, 0x0c ]
                        , B.pack [ 0xfa, 0x82, 0x82, 0x82 ]
                        ]
        let invalid = toProtectionPassword $ B.concat [prefix, bad, suffix]
        return $ Nothing === passwordToString invalid
    ]
