-- |
-- Module      : Crypto.Store.Cipher.RC2.Primitive
-- License     : BSD-style
-- Maintainer  : Olivier Chéron <olivier.cheron@gmail.com>
-- Stability   : stable
-- Portability : good
--
{-# LANGUAGE MagicHash #-}
module Crypto.Store.Cipher.RC2.Primitive
    ( Key
    , buildKey
    , encrypt
    , decrypt
    ) where

import Control.Monad (forM_)

import           Data.Bits
import           Data.ByteArray (ByteArrayAccess)
import qualified Data.ByteArray as B
import           Data.Memory.Endian (fromLE)
import           Data.Word

import Foreign.Marshal.Utils (copyBytes)
import Foreign.Storable

import GHC.Ptr (Ptr(..))

import Crypto.Store.Block


-- | Expanded RC2 key
newtype Key = Key (Block Word16) -- [ K[0], K[1], ..., K[63] ]

data Q = Q {-# UNPACK #-} !Word16 {-# UNPACK #-} !Word16
           {-# UNPACK #-} !Word16 {-# UNPACK #-} !Word16


-- Utilities

decomp64 :: Word64 -> Q
decomp64 x =
    let d = fromIntegral (x `shiftR` 48)
        c = fromIntegral (x `shiftR` 32)
        b = fromIntegral (x `shiftR` 16)
        a = fromIntegral  x
    in Q a b c d

comp64 :: Q -> Word64
comp64 (Q a b c d) =
    (fromIntegral d `shiftL` 48) .|.
    (fromIntegral c `shiftL` 32) .|.
    (fromIntegral b `shiftL` 16) .|.
     fromIntegral a

getR :: Q -> Word8 -> Word16
getR (Q a b c d) i =
    case i .&. 3 of
        0 -> a
        1 -> b
        2 -> c
        _ -> d
{-# INLINE getR #-}

setR :: Q -> Word8 -> Word16 -> Q
setR (Q a b c d) i x =
    case i .&. 3 of
        0 -> Q x b c d
        1 -> Q a x c d
        2 -> Q a b x d
        _ -> Q a b c x
{-# INLINE setR #-}

rol :: Word8 -> Word16 -> Word16
rol i =
    case i .&. 3 of
        0 -> flip rotateL 1
        1 -> flip rotateL 2
        2 -> flip rotateL 3
        _ -> flip rotateL 5
{-# INLINE rol #-}

ror :: Word8 -> Word16 -> Word16
ror i =
    case i .&. 3 of
        0 -> flip rotateR 1
        1 -> flip rotateR 2
        2 -> flip rotateR 3
        _ -> flip rotateR 5
{-# INLINE ror #-}

f5 :: (a -> a) -> a -> a
f5 f = f . f . f . f . f

f6 :: (a -> a) -> a -> a
f6 f = f . f . f . f . f . f


-- Encryption

-- | Encrypts a block using the specified key
encrypt :: Key -> Word64 -> Word64
encrypt k = comp64 . enc k . decomp64

enc :: Key -> Q -> Q
enc k r =
    fst $ f5 (mixingRound k) $ mashingRound k
        $ f6 (mixingRound k) $ mashingRound k
        $ f5 (mixingRound k) (r, 0)

-- Decryption

-- | Decrypts a block using the specified key
decrypt :: Key -> Word64 -> Word64
decrypt k = comp64 . dec k . decomp64

dec :: Key -> Q -> Q
dec k r =
    fst $ f5 (rmixingRound k) $ rmashingRound k
        $ f6 (rmixingRound k) $ rmashingRound k
        $ f5 (rmixingRound k) (r, 63)


-- Encryptiong rounds

mixUp :: Key -> Word8 -> (Q, Int) -> (Q, Int)
mixUp k i input@(r, j) = seq r' $ seq j' (r', j')
  where j' = j + 1
        r' = setR r i (rol i (ri + gmix k i input))
        ri = getR r i
{-# INLINE mixUp #-}

mixingRound :: Key -> (Q, Int) -> (Q, Int)
mixingRound k = mixUp k 3 . mixUp k 2 . mixUp k 1 . mixUp k 0

mash :: Key -> Word8 -> (Q, Int) -> (Q, Int)
mash = gmash (+)
{-# INLINE mash #-}

mashingRound :: Key -> (Q, Int) -> (Q, Int)
mashingRound k = mash k 3 . mash k 2 . mash k 1 . mash k 0


-- Decryption rounds

rmixUp :: Key -> Word8 -> (Q, Int) -> (Q, Int)
rmixUp k i input@(r, j) = seq r' $ seq j' (r', j')
  where j' = j - 1
        r' = setR r i (ri - gmix k i input)
        ri = ror i (getR r i)
{-# INLINE rmixUp #-}

rmixingRound :: Key -> (Q, Int) -> (Q, Int)
rmixingRound k = rmixUp k 0 . rmixUp k 1 . rmixUp k 2 . rmixUp k 3

rmash :: Key -> Word8 -> (Q, Int) -> (Q, Int)
rmash = gmash (-)
{-# INLINE rmash #-}

rmashingRound :: Key -> (Q, Int) -> (Q, Int)
rmashingRound k = rmash k 0 . rmash k 1 . rmash k 2 . rmash k 3


-- Generic rounds

gmix :: Key -> Word8 -> (Q, Int) -> Word16
gmix (Key k) i (r, j) = kj + (ri1 .&. ri2) + (complement ri1 .&. ri3)
  where ri1 = getR r (i - 1)
        ri2 = getR r (i - 2)
        ri3 = getR r (i - 3)
        kj  = unsafeIndex k (Offset j)
{-# INLINE gmix #-}

gmash :: (Word16 -> Word16 -> Word16)
      -> Key -> Word8 -> (Q, Int) -> (Q, Int)
gmash op (Key k) i (r, j) = seq r' $ seq j (r', j)
  where r'  = setR r i (ri `op` kp)
        ri  = getR r i
        ri1 = getR r (i - 1)
        kp  = unsafeIndex k $ Offset (fromIntegral ri1 .&. 63)
{-# INLINE gmash #-}


-- Key expansion

-- | Perform key expansion
buildKey :: ByteArrayAccess key
         => Int    -- ^ Effective key length in bits
         -> key    -- ^ Input key between 1 and 128 bytes
         -> Key    -- ^ Expanded key
buildKey t1 key = Key $ doCast $ createWithPtr (CountOf 128) $ \p -> do
    B.copyByteArrayToPtr key p

    forM_ [t .. 127] $ \i -> do
        pos <- (+) <$> peekElemOff p (i - 1) <*> peekElemOff p (i - t)
        let b = unsafeIndex piTable (fromIntegral pos)
        pokeElemOff p i b

    pos' <- (.&. tm) <$> peekElemOff p (128 - t8)
    let b' = unsafeIndex piTable (fromIntegral pos')
    pokeElemOff p (128 - t8) b'

    forM_ [127 - t8, 126 - t8 .. 0] $ \i -> do
        pos <- xor <$> peekElemOff p (i + 1) <*> peekElemOff p (i + t8)
        let b = unsafeIndex piTable (fromIntegral pos)
        pokeElemOff p i b

  where t  = B.length key
        t8 = (t1 + 7) `div` 8
        tm | t1 == 8 * t8 = 255
           | otherwise    = 255 `mod` shiftL 1 (8 + t1 - 8 * t8)

        doCast :: Block Word8 -> Block Word16
        doCast = Crypto.Store.Block.map fromLE . unsafeCast


-- PITABLE

piTable :: Block Word8
piTable = createWithPtr (CountOf bytes) $ \p -> copyBytes p (Ptr addr#) bytes
  where
    bytes = 256
    addr# =
        "\xd9\x78\xf9\xc4\x19\xdd\xb5\xed\x28\xe9\xfd\x79\x4a\xa0\xd8\x9d\
        \\xc6\x7e\x37\x83\x2b\x76\x53\x8e\x62\x4c\x64\x88\x44\x8b\xfb\xa2\
        \\x17\x9a\x59\xf5\x87\xb3\x4f\x13\x61\x45\x6d\x8d\x09\x81\x7d\x32\
        \\xbd\x8f\x40\xeb\x86\xb7\x7b\x0b\xf0\x95\x21\x22\x5c\x6b\x4e\x82\
        \\x54\xd6\x65\x93\xce\x60\xb2\x1c\x73\x56\xc0\x14\xa7\x8c\xf1\xdc\
        \\x12\x75\xca\x1f\x3b\xbe\xe4\xd1\x42\x3d\xd4\x30\xa3\x3c\xb6\x26\
        \\x6f\xbf\x0e\xda\x46\x69\x07\x57\x27\xf2\x1d\x9b\xbc\x94\x43\x03\
        \\xf8\x11\xc7\xf6\x90\xef\x3e\xe7\x06\xc3\xd5\x2f\xc8\x66\x1e\xd7\
        \\x08\xe8\xea\xde\x80\x52\xee\xf7\x84\xaa\x72\xac\x35\x4d\x6a\x2a\
        \\x96\x1a\xd2\x71\x5a\x15\x49\x74\x4b\x9f\xd0\x5e\x04\x18\xa4\xec\
        \\xc2\xe0\x41\x6e\x0f\x51\xcb\xcc\x24\x91\xaf\x50\xa1\xf4\x70\x39\
        \\x99\x7c\x3a\x85\x23\xb8\xb4\x7a\xfc\x02\x36\x5b\x25\x55\x97\x31\
        \\x2d\x5d\xfa\x98\xe3\x8a\x92\xae\x05\xdf\x29\x10\x67\x6c\xba\xc9\
        \\xd3\x00\xe6\xcf\xe1\x9e\xa8\x2c\x63\x16\x01\x3f\x58\xe2\x89\xa9\
        \\x0d\x38\x34\x1b\xab\x33\xff\xb0\xbb\x48\x0c\x5f\xb9\xb1\xcd\x2e\
        \\xc5\xf3\xdb\x47\xe5\xa5\x9c\x77\x0a\xa6\x20\x68\xfe\x7f\xc1\xad"#
