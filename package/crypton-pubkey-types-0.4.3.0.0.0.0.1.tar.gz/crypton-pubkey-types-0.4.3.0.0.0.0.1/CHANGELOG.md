Change log for `crypton-pubkey-types`

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to the
[Haskell Package Versioning Policy](https://pvp.haskell.org/).

## 0.5.0

* Rename `crypto-pubkey-types` package as `crypton-pubkey-types`.
* Depend on `crypton-asn1-types` instead of `asn1-types`.
* Depend on `crypton-asn1-encoding` instead of `asn1-encoding`.
* Change maintainer field to `Pranay Sashank <pranaysashank@gmail.com>`.
* Add `CHANGELOG.md`.
* Add `README.md`.
