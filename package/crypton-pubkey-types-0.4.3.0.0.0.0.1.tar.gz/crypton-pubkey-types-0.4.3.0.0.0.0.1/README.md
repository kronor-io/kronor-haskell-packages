![GitHub Actions status](https://github.com/kronor-io/crypton-pubkey-types/workflows/Haskell%20CI/badge.svg)

crypton-pubkey-types
==========

crypton-pubkey-types is a fork of crypto-pubkey-types to depend on the
crypton-asn1-* universe of packages as asn1-* packages are
unmaintained

Documentation: [crypton-pubkey-types on hackage](http://hackage.haskell.org/package/crypton-pubkey-types)
