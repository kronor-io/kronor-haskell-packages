## yesod-static

Static file serving subsite for Yesod Web Framework.
