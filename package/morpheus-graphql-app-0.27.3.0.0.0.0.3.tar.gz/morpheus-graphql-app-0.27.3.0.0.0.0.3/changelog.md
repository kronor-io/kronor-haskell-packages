# Changelog

see latest changes on [Github](https://github.com/morpheusgraphql/morpheus-graphql/releases)

## 0.19.0 - 21.03.2022

## 0.18.0 - 08.11.2021

- Data.Morpheus.App.NamedResolvers (inspired by apollo [named resolvers](https://www.apollographql.com/docs/apollo-server/data/resolvers/#as-this-example-shows)

## 0.17.0 (Initial Release) - 25.02.2021
