module OpenTelemetry.Processor.LogRecord (
  LogRecordProcessor (..),
  ShutdownResult (..),
) where

import OpenTelemetry.Internal.Common.Types
import OpenTelemetry.Internal.Logs.Types

