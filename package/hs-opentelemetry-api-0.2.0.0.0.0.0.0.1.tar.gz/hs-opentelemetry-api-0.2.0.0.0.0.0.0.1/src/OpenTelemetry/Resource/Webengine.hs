-----------------------------------------------------------------------------

-----------------------------------------------------------------------------

{- |
 Module      :  OpenTelemetry.Resource.Telemetry
 Copyright   :  (c) Ian Duncan, 2021
 License     :  BSD-3
 Description :  Not implemented
 Maintainer  :  Ian Duncan
 Stability   :  experimental
 Portability :  non-portable (GHC extensions)

 Not implemented. Please file a GitHub issue if you want this.
-}
module OpenTelemetry.Resource.Webengine where

