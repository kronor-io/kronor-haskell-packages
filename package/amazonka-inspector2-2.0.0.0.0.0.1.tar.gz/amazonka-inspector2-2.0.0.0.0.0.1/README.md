# Amazon Inspector2 SDK

* [Version](#version)
* [Description](#description)
* [Contribute](#contribute)
* [Licence](#licence)


## Version
 
`2.0` - Derived from API version @2020-06-08@ of the AWS service descriptions, licensed under Apache 2.0.

## Description

Documentation is available via [Hackage](http://hackage.haskell.org/package/amazonka-inspector2)
and the [AWS API Reference](https://aws.amazon.com/documentation/).

The types from this library are intended to be used with [amazonka](http://hackage.haskell.org/package/amazonka),
which provides mechanisms for specifying AuthN/AuthZ information, sending requests,
and receiving responses.

Lenses are used for constructing and manipulating types,
due to the depth of nesting of AWS types and transparency regarding
de/serialisation into more palatable Haskell values.
The provided lenses should be compatible with any of the major lens libraries
[lens](http://hackage.haskell.org/package/lens) or [lens-family-core](http://hackage.haskell.org/package/lens-family-core).

See [Amazonka.Inspector2](http://hackage.haskell.org/package/amazonka-inspector2/docs/Amazonka-Inspector2.html)
or [the AWS documentation](https://aws.amazon.com/documentation/) to get started.


## Contribute

For any problems, comments, or feedback please create an issue [here on GitHub](https://github.com/brendanhay/amazonka/issues).

> _Note:_ this library is an auto-generated Haskell package. Please see `amazonka-gen` for more information.


## Licence

`amazonka-inspector2` is released under the [Mozilla Public License Version 2.0](http://www.mozilla.org/MPL/).

Parts of the code are derived from AWS service descriptions, licensed under Apache 2.0.
Source files subject to this contain an additional licensing clause in their header.
