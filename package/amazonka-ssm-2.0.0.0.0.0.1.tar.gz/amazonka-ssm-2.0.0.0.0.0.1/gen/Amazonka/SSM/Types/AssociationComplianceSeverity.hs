{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE DerivingStrategies #-}
{-# LANGUAGE GeneralizedNewtypeDeriving #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE StrictData #-}
{-# LANGUAGE NoImplicitPrelude #-}
{-# OPTIONS_GHC -fno-warn-unused-imports #-}

-- Derived from AWS service descriptions, licensed under Apache 2.0.

-- |
-- Module      : Amazonka.SSM.Types.AssociationComplianceSeverity
-- Copyright   : (c) 2013-2023 Brendan Hay
-- License     : Mozilla Public License, v. 2.0.
-- Maintainer  : Brendan Hay
-- Stability   : auto-generated
-- Portability : non-portable (GHC extensions)
module Amazonka.SSM.Types.AssociationComplianceSeverity
  ( AssociationComplianceSeverity
      ( ..,
        AssociationComplianceSeverity_CRITICAL,
        AssociationComplianceSeverity_HIGH,
        AssociationComplianceSeverity_LOW,
        AssociationComplianceSeverity_MEDIUM,
        AssociationComplianceSeverity_UNSPECIFIED
      ),
  )
where

import qualified Amazonka.Core as Core
import qualified Amazonka.Data as Data
import qualified Amazonka.Prelude as Prelude

newtype AssociationComplianceSeverity = AssociationComplianceSeverity'
  { fromAssociationComplianceSeverity ::
      Data.Text
  }
  deriving stock
    ( Prelude.Show,
      Prelude.Read,
      Prelude.Eq,
      Prelude.Ord,
      Prelude.Generic
    )
  deriving newtype
    ( Prelude.Hashable,
      Prelude.NFData,
      Data.FromText,
      Data.ToText,
      Data.ToByteString,
      Data.ToLog,
      Data.ToHeader,
      Data.ToQuery,
      Data.FromJSON,
      Data.FromJSONKey,
      Data.ToJSON,
      Data.ToJSONKey,
      Data.FromXML,
      Data.ToXML
    )

pattern AssociationComplianceSeverity_CRITICAL :: AssociationComplianceSeverity
pattern AssociationComplianceSeverity_CRITICAL = AssociationComplianceSeverity' "CRITICAL"

pattern AssociationComplianceSeverity_HIGH :: AssociationComplianceSeverity
pattern AssociationComplianceSeverity_HIGH = AssociationComplianceSeverity' "HIGH"

pattern AssociationComplianceSeverity_LOW :: AssociationComplianceSeverity
pattern AssociationComplianceSeverity_LOW = AssociationComplianceSeverity' "LOW"

pattern AssociationComplianceSeverity_MEDIUM :: AssociationComplianceSeverity
pattern AssociationComplianceSeverity_MEDIUM = AssociationComplianceSeverity' "MEDIUM"

pattern AssociationComplianceSeverity_UNSPECIFIED :: AssociationComplianceSeverity
pattern AssociationComplianceSeverity_UNSPECIFIED = AssociationComplianceSeverity' "UNSPECIFIED"

{-# COMPLETE
  AssociationComplianceSeverity_CRITICAL,
  AssociationComplianceSeverity_HIGH,
  AssociationComplianceSeverity_LOW,
  AssociationComplianceSeverity_MEDIUM,
  AssociationComplianceSeverity_UNSPECIFIED,
  AssociationComplianceSeverity'
  #-}
