{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE DerivingStrategies #-}
{-# LANGUAGE GeneralizedNewtypeDeriving #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE StrictData #-}
{-# LANGUAGE NoImplicitPrelude #-}
{-# OPTIONS_GHC -fno-warn-unused-imports #-}

-- Derived from AWS service descriptions, licensed under Apache 2.0.

-- |
-- Module      : Amazonka.SSM.Types.DocumentReviewAction
-- Copyright   : (c) 2013-2023 Brendan Hay
-- License     : Mozilla Public License, v. 2.0.
-- Maintainer  : Brendan Hay
-- Stability   : auto-generated
-- Portability : non-portable (GHC extensions)
module Amazonka.SSM.Types.DocumentReviewAction
  ( DocumentReviewAction
      ( ..,
        DocumentReviewAction_Approve,
        DocumentReviewAction_Reject,
        DocumentReviewAction_SendForReview,
        DocumentReviewAction_UpdateReview
      ),
  )
where

import qualified Amazonka.Core as Core
import qualified Amazonka.Data as Data
import qualified Amazonka.Prelude as Prelude

newtype DocumentReviewAction = DocumentReviewAction'
  { fromDocumentReviewAction ::
      Data.Text
  }
  deriving stock
    ( Prelude.Show,
      Prelude.Read,
      Prelude.Eq,
      Prelude.Ord,
      Prelude.Generic
    )
  deriving newtype
    ( Prelude.Hashable,
      Prelude.NFData,
      Data.FromText,
      Data.ToText,
      Data.ToByteString,
      Data.ToLog,
      Data.ToHeader,
      Data.ToQuery,
      Data.FromJSON,
      Data.FromJSONKey,
      Data.ToJSON,
      Data.ToJSONKey,
      Data.FromXML,
      Data.ToXML
    )

pattern DocumentReviewAction_Approve :: DocumentReviewAction
pattern DocumentReviewAction_Approve = DocumentReviewAction' "Approve"

pattern DocumentReviewAction_Reject :: DocumentReviewAction
pattern DocumentReviewAction_Reject = DocumentReviewAction' "Reject"

pattern DocumentReviewAction_SendForReview :: DocumentReviewAction
pattern DocumentReviewAction_SendForReview = DocumentReviewAction' "SendForReview"

pattern DocumentReviewAction_UpdateReview :: DocumentReviewAction
pattern DocumentReviewAction_UpdateReview = DocumentReviewAction' "UpdateReview"

{-# COMPLETE
  DocumentReviewAction_Approve,
  DocumentReviewAction_Reject,
  DocumentReviewAction_SendForReview,
  DocumentReviewAction_UpdateReview,
  DocumentReviewAction'
  #-}
