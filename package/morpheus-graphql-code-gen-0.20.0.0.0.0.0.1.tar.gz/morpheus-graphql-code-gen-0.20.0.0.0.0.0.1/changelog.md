# Changelog

see latest changes on [Github](https://github.com/morpheusgraphql/morpheus-graphql/releases)

## 0.18.0 - 08.11.2021
