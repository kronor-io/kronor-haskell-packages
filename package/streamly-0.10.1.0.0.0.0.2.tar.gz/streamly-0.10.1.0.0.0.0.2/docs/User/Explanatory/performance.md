# Performance

Streamly is highly optimized for performance, it is designed for
high performing, concurrent and scalable applications. Please see the
[streaming-benchmarks](https://github.com/composewell/streaming-benchmarks)
package for microbencmarks measuring the performance of streamly and comparing
it with other streaming libraries.
