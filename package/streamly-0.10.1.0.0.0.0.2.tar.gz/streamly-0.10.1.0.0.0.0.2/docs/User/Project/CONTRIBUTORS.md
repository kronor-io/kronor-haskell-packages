This is a list of code contributors to this library. For issue contributors
please see https://github.com/composewell/streamly/issues.

Use `git shortlog -sn tag1...tag2` on the git repository to get a list of
contributors between two repository tags.

## 0.10.0

* Adithya Kumar
* Harendra Kumar
* Ranjeet Kumar Ranjan
* Shlok Datye
* Bodigrim

## 0.9.0

* Harendra Kumar
* Ranjeet Kumar Ranjan
* Adithya Kumar
* Francesco Gazzetta
* Ishan Bhanuka

## 0.8.2

* Adithya Kumar
* Harendra Kumar
* Ranjeet Kumar Ranjan
* Anurag Hooda
* andremarianiello

## 0.8.1.1

* Harendra Kumar
* Julian Ospald

## 0.8.1

* Harendra Kumar
* Adithya Kumar
* Ranjeet Kumar Ranjan
* Julian Ospald
* Sanchayan Maity

## 0.8.0

* Harendra Kumar
* Adithya Kumar
* Pranay Sashank
* Ranjeet Kumar Ranjan
* Anurag Hooda
* Ahmed Zaheer Dadarkar
* Shruti Umat
* Joseph Koshy (Google LLC.)
* Sanchayan Maity
* Kirill Elagin
* Shlok Datye
* Julian Ospald
* George Thomas
* endgame

## 0.7.3

* Pranay Sashank
* Adithya Kumar
* Julian Ospald

## 0.7.2

* Harendra Kumar
* Pranay Sashank
* Adithya Kumar
* Sanchayan Maity
* Julian Ospald
* Shlok Datye

## 0.7.1

* Harendra Kumar
* Pranay Sashank
* Adithya Kumar
* Sanchayan Maity
* Brian Wignall
* Julian Ospald
* Lucian Ursu

## 0.7.0

* Harendra Kumar
* Pranay Sashank
* Artyom Kazak
* David Feuer
* Adithya Kumar
* Aravind Gopal

## 0.6.1

* Harendra Kumar
* Mariusz Ryndzionek
* Luke Clifton
* Nicolas Henin

## 0.6.0

* Harendra Kumar
* Pranay Sashank
* Abhiroop Sarkar
* Michael Sloan

## 0.5.2

* Harendra Kumar
* Keith

## 0.5.1

* Harendra Kumar

## 0.5.0

* Harendra Kumar
* Veladus
* Tim Buckley

## 0.4.1

* Harendra Kumar

## 0.4.0

* Harendra Kumar

## 0.3.0

* Harendra Kumar
* Xiaokui Shu
* k0ral

## 0.2.1

* Harendra Kumar

## 0.2.0

* Harendra Kumar
* Abhiroop Sarkar
* Hussein Ait Lahcen

## 0.1.2

* Harendra Kumar
* Abhiroop Sarkar
* Hussein Ait Lahcen

## 0.1.1

* Harendra Kumar
* Veladus
* Abhiroop Sarkar
* Sibi Prabakaran

## 0.1.0

* Harendra Kumar
* Sibi Prabakaran
