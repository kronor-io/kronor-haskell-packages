#!/usr/bin/env sh

tr [a-z] [A-Z] >&2
