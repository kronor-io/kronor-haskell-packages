module OpenTelemetry.Exporter.OTLP.LogRecord () where

