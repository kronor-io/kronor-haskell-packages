module OpenTelemetry.Exporter.OTLP
  {-# DEPRECATED "use OpenTelemetry.Exporter.OTLP.Span instead" #-} (
  module OpenTelemetry.Exporter.OTLP.Span,
) where

import OpenTelemetry.Exporter.OTLP.Span

