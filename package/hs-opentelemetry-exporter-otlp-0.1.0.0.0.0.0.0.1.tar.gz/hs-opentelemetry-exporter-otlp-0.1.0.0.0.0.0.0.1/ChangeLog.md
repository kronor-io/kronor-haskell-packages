# Changelog for hs-opentelemetry-exporter-otlp

## 0.1.0.0

- Export dropped span, link, event, and attribute counts
- Add gzip compression support
- Swallow errors from sending data to localhost

## 0.0.1.0

- Initial release
