module Hasql.Pipeline
  ( Pipeline,
    statement,
  )
where

import Hasql.Pipeline.Core
