# Morpheus GraphQL Core

provides the following core functionalities
for building GraphQL Server, Client:

- AST
- parsing
- validation
- pretty-printing
- utils
