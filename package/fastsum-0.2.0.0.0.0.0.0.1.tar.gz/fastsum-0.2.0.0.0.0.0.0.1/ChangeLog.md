# v0.2.0.0

Support GHC 9.2 by enabling use of `template-haskell` versions >= 2.19.

Add an `Eq1` constraint to the `Hashable1` constraint to satisfy newer `hashable` versions.

# v0.1.1.1

Enable use of `template-haskell` versions >= 2.15.

# v0.1.1

Added `projectGuard` and `NFData`/`NFData1` instances.

# v0.1

Initial release.
