# Changelog for otlp

## Unreleased

- Support OTLP specification v1.7

## 0.1.0.0

Support OTLP specification v1.0.0

## 0.0.1.2

Support additional status codes (408, 5xx) as transient & able to retry

## 0.0.1.0

Initial release
